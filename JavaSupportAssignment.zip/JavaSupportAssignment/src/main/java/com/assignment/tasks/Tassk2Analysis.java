package com.assignment.tasks;

public class Tassk2Analysis {
	
	/*
	 * Q1. what is the exact cause of ConcurentModificationException in java?
	 * --> ConcurrentModificationException is a runtime exception that occurs when a collection,such as an arrayList, is structurally modified while it is being traversed using an iterator or an enhanced for-loop.
	 * a structural modification means adding or removing elements from the collections .java collections maintain an internal modification count(modCount).when an Iterator is created , it stores the current value of 'modCount' as  'expectedmodCount'. 
	 * during iteration, if the collection is modified directly(for example,by calling'list.remove()' or 'list.add()'),the 'modCount' changes , but the Iterator's expectedModCount does not . on the next iteration,the iterator detects this mismatch and throw a concurrentModificationException.
	 * this exception is fail-fast, meaning it immediately detects unsafe modifications to prevent unpredictable behavior.
	 * 
	 * 
	 * 
	 * Q2. What code pattern at line 142 most likely triggered this error?
	 * --->The stack trace indicates that the exception occurred while iterating over an ArrayList.

	 * The most likely code pattern is:
	 * `java
		for (Transaction transaction : transactions) {
		    if (transaction.isInvalid()) {
		        transactions.remove(transaction);
		    }
		}		
	 * or
	 * Iterator<Transaction> iterator = transactions.iterator();
		while (iterator.hasNext()) {
		    Transaction transaction = iterator.next();
		
		    if (transaction.isInvalid()) {
		        transactions.remove(transaction);
		    }
		}
	 * In both cases, the collection is modified directly while the Iterator is still traversing it, causing ConcurrentModificationException.
	 * 
	 * 
	 * 
	 * Q3. Provide the minimal code change (one or two lines) that resolves this safely.
	 * -->The safest minimal fix is to remove elements using the Iterator itself instead of modifying the collection directly.
		 * ```java
		Iterator<Transaction> iterator = transactions.iterator();
		
		while (iterator.hasNext()) {
		    Transaction transaction = iterator.next();
		
		    if (transaction.isInvalid()) {
		        iterator.remove();
		    }
		}
		
		
		Using `iterator.remove()` keeps the Iterator's internal state synchronized with the collection, preventing ConcurrentModificationException.
		
		
	 */

}
