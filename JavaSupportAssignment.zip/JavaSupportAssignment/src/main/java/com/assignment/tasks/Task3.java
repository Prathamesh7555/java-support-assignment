package com.assignment.tasks;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class Task3 {
	
	public class BankStatementBatchProcessor{
		
		
		// fix : replaced int with atomicInteger because processedCount is updatedd
		// by multiple threads simultaneously . atomaicInteger provides thread-safe
		// atomic increment operation and prevents race conditions.
	    private final AtomicInteger processedCount = new AtomicInteger(0);
	    
	    public void process(List<StatementRecord> records) throws InterruptedException {
	        
	    	ExecutorService executor = Executors.newFixedThreadPool(10);
	        for (StatementRecord record : records) {
	            executor.submit(() -> {
	                processRecord(record);
	                
	                // FIX: Use atomic increment instead of processedCount++
	                // because ++ is not thread-safe in a multi-threaded environment.
	                processedCount.incrementAndGet();

	            });
	                

	        }
	        executor.shutdown();
	        executor.awaitTermination(5, TimeUnit.MINUTES);
	    }

	    public int getProcessedCount() {
	        return processedCount.get();
	    }

	    private void processRecord(StatementRecord record) {
	        // Existing business logic

	    }
}
}