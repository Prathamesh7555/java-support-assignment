package com.assignment.tasks;

import javax.swing.text.Document;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Task5 {
	

public class DocumentValidator {

    // fix: Use SLF4J logger instead of printStackTrace().
    private static final Logger logger =LoggerFactory.getLogger(DocumentValidator.class);

    public ValidationResult validate(Document doc) {

        try {
            if (doc == null) {
                // fix: Throw IllegalArgumentException for expected validation failures.
                throw new IllegalArgumentException("Document is null");
            }
            String content = doc.extractContent();
            if (content == null || content.isEmpty()) {
                // fix: Throw IllegalArgumentException for invalid document content.
                throw new IllegalArgumentException("Empty content");
            }
            return runValidationRules(content);

        } catch (IllegalArgumentException e) {
            // fix: Log expected validation failures at WARN level
            // instead of printing stack trace.
            logger.warn("Validation failed: {}", e.getMessage());
            return null;
        } catch (Exception e) {

            // fix: Log unexpected runtime errors with stack trace.
            logger.error("Unexpected error while validating document.", e);

            return null;
        }
    }

    public void validateBatch(List<Document> docs) {
        for (Document doc : docs) {
            try {
                ValidationResult r = validate(doc);

                // fix: Check for null before calling isValid()
                // to avoid NullPointerException.
                if (r != null && r.isValid()) {
                    saveResult(r);
                }
            } catch (Exception e) {

                // FIX: Do not silently swallow exceptions.
                logger.error("Error while processing document in batch.", e);
            }
        }
    }

    private ValidationResult runValidationRules(String content) {
        return new ValidationResult();
    }
    private void saveResult(ValidationResult result) {
        // Existing logic
    }
}

}
