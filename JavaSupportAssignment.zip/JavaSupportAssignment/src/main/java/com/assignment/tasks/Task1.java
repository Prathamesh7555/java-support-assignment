package com.assignment.tasks;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
public class Task1 {
	
	
	public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts){
		
		
		//fix : initialize result list to avoid NullPointerException
		List<LoanAccount> result = new ArrayList<>();
		
		//fix : handle null input list to avoid nullPointerException
		if(accounts == null) {
			return result;
		}
		
		
		for (LoanAccount account : accounts) {
			
			//fix : skip null account objects defensive check.
			if(account == null) {
				continue;
				
			}
			
			
			//fix: check duDate for null brfore calling before
			if(account.getDueDate() != null && account.getDueDate().before(new Date())) {
				
				//ffix : only overdue accounts with outstanding balance greater than zero 
				// should be returned
				if (account.getOutstandingBalance() > 0) {
					result.add(account);
				}
			}
		}
		return result;
	}

}
